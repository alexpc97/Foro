<?php

session_start();

require_once('conecta_bd.php');
require_once('clases/usuarios.php');
require_once('clases/funciones.php');
require_once('clases/tema.php');

switch ($_SESSION['tipo']) {
    case 'creador':
        require_once('menu/nav.html');
        break;
    case 'admin':
        require_once('menu/admin.html');
        break;
    default:
        # code...
        break;
}
// echo  $_SESSION['nombre'] . ' : ' . $_SESSION['tipo'] . ' : ' . $_SESSION['temas'];

$usuario = $_SESSION['nombre'];
$tipo = $_SESSION['tipo'];

if (isset($_POST['enviar'])) {
    $categoria = $_POST['categoria'];
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $fecha = $_POST['data_creacion'];

    $_SESSION['temas'] += 1;

    $temas = new temas($titulo, $descripcion, $fecha, $categoria, $usuario, $tipo);

    temas::crear($temas);

    actualizartemas( $_SESSION['temas'],$usuario);
}


if (isset($_GET['delete'])) {
    $elemento = $_GET['delete'];
    $elemento_nom = $_GET['usuario'];
    $borrar = "DELETE FROM temas WHERE nombre = '$elemento'";
    $conexion->query($borrar);
    // $conexion->close();
    $_SESSION['temas'] -= 1;
    actualizartemas( $_SESSION['temas'],$elemento_nom);
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/temas.css">
    <title>Document</title>
</head>

<body>

    <div class="wrapper">
        <div class="logo">
            <img src="https://cdn-icons-png.flaticon.com/512/2412/2412855.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            Tema
        </div>
        <form class="p-3 mt-3" action="" method="post">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="text" name="titulo" id="userName" placeholder="Titulo" required>
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="date" name="data_creacion" id="pwd" required>
            </div>
            <div>
                <span class="far fa-user"></span>
                <select class="form-field d-flex align-items-center" name="categoria" id="">
                    <?php
                    categorias();
                    ?>
                </select>
            </div>
            <div class=" d-flex align-items-center" name="" id="">
                <textarea name="descripcion" class="avatar" cols="50" rows="10" placeholder="Escriba una descripcion" required></textarea>
            </div>
            <button type="submit" class="btn mt-3 boton" name="enviar" value="enviar">Crear</button>
        </form>

    </div>
</body>

</html>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cards.css">
    <title>Document</title>
</head>

<body>
    <section class="wrappers">
        <div class="container">
            <div class="row">
                <div class="col text-center mb-5">
                    <h1 class="display-4">Temas </h1>
                    <p class="lead">Aquí podras ver los mejores temas creados </p>
                </div>
            </div>
            <div class="row">
                <?php
                if($_SESSION['tipo'] == "admin"){
                    $sql = "SELECT * FROM temas ";
                }
                else{
                    $sql = "SELECT * FROM temas WHERE usuario = '$usuario' ";
                }
                // $sql = "SELECT * FROM temas WHERE usuario = '$usuario' ";
                $result = $conexion->query($sql);
                if ($result->num_rows > 0) {
                    while ($filas = $result->fetch_array()) {


                ?>
                  
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-4">
                            <div class="card text-white card-has-bg click-col" style="background-image:url('https://source.unsplash.com/600x900/?tech,street');">
                                <img class="card-img d-none" src="https://source.unsplash.com/600x900/?tech,street" alt="Goverment Lorem Ipsum Sit Amet Consectetur dipisi?">
                                <div class="card-img-overlay d-flex flex-column">
                                    <div class="card-body">
                                      
                                        <h4 class="card-title mt-0 "><a class="text-white" herf="#"><?php echo $filas['nombre']; ?></a></h4>
                                        <p class="card-text"> <?php echo $filas['descripcion'] ?></p>
                                        <small><i class="far fa-clock"></i> <?php echo $filas['data_creacion']; ?></small>
                                    </div>
                                    <div class="card-footer">
                                    
                                        <div class="media">
                                            <img class="mr-3 rounded-circle" src="https://assets.codepen.io/460692/internal/avatars/users/default.png" alt="Generic placeholder image" style="max-width:50px; ">
                                            <div class="media-body">
                                                <h6 class="my-0 text-white d-block"><?php echo $filas['usuario'] ?></h6>
                                                <small><i class="far fa-clock"></i> <?php echo $filas['tipo_user']; ?></small>
                                                <a href="temas.php?delete=<?php echo $filas['nombre']; ?>&usuario=<?php echo $filas['usuario']; ?>" class="btn btn-primary borrar">Borrar</a>
                                              
                                            </div>
                                            
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>

                <?php
                    }
                }
                ?>


            </div>

        </div>
    </section>

</body>

</html>