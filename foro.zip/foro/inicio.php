<?php
session_start();

require_once('conecta_bd.php');

require_once('clases/usuarios.php');



switch ($_SESSION['tipo']) {
    case 'creador':
        require_once('menu/nav.html');
        break;
    case 'admin':
        require_once('menu/admin.html');
        break;
    case 'lector':
        require_once('menu/lector.html');
        break;
    case 'comentador':
        require_once('menu/lector.html');
        break;
    default:
        # code...
        break;
}
// echo  $_SESSION['nombre'] . ' : ' . $_SESSION['tipo'] . ' : ' . $_SESSION['temas'];



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/inicio.css">
    <title>Document</title>
</head>

<body>

<div class="wrapper">
        <div class="logo">
            <img src="https://cdn-icons-png.flaticon.com/512/2412/2412855.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            <h1>Bienvenido al foro usuari@ <?php echo  $_SESSION['nombre']?> </h1>
        </div>
    </div>

</body>

</html>