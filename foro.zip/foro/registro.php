<?php



require_once('conecta_bd.php');
// require_once('menu/nav.html');
require_once('clases/usuarios.php');
session_start();

switch ($_SESSION['tipo']) {
    case 'creador':
        require_once('menu/nav.html');
        break;
    case 'admin':
        require_once('menu/admin.html');
        break;
    default:
        # code...
        break;
}


if (isset($_POST['enviar'])) {
    $email = $_POST['email'];
    $nombre = $_POST['nombre'];
    $pass = $_POST['pass'];
    $tipo = $_POST['tipo'];
    $avatar = $_POST['avatar'];

    $nuevo =  new usuarios($nombre, $email, $pass, $tipo, $avatar);
 

    $prueba = usuarios::crear($nuevo);
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.1.3/css/bootstrap.min.css" rel="stylesheet">
  <script src="bootstrap-5.1.3/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <title>Document</title>
</head>

<body>

    <div class="wrapper">
        <div class="logo">
            <img src="https://cdn-icons-png.flaticon.com/512/2412/2412855.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            Registro
        </div>
        <form class="p-3 mt-3" action="" method="post">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="text" name="nombre" id="userName" placeholder="nombre" required>
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="email" name="email" id="userName" placeholder="Email" required>
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="pass" id="pwd" placeholder="Password" required>
            </div>
            <div>
                <span class="far fa-user"></span>
                <select class="form-field d-flex align-items-center" name="tipo" id="">
                    <option value="admin">admin</option>
                    <option value="creador">creador</option>
                    <option value="comentador">comentador</option>
                    <option value="lector">lector</option>
                </select>
            </div>
            <div class="d-flex align-items-center" name="" id="">

                <input type="color" name="avatar" class="avatar">
            </div>
            <button type="submit" class="btn mt-3 boton" name="enviar" value="enviar">Registrar</button>
        </form>
        <div class="text-center fs-6">
            <a href="index.php">Login</a>
        </div>
    </div>
</body>

</html>