<?php

// session_destroy();
require_once('conecta_bd.php');
// require_once('menu/nav.html');
require_once('clases/usuarios.php');

session_start();



if (isset($_POST['enviar'])) {
    $email = $_POST['email'];
    $pass = $_POST['pass'];

    // $nuevo =  new usuarios($user, $email, $pass, $tipo, $avatar);
    // $prueba = usuarios::comprobar($nuevo);

    $sql = "SELECT * FROM usuarios";
    $result = $conexion->query($sql);



    if ($result->num_rows > 0) {
        while ($filas = $result->fetch_array()) {
            if ($filas['email'] == $email && $filas['pass'] == $pass) {
                $_SESSION['tipo'] = $filas['tipo_user'];
                $_SESSION['nombre'] = $filas['nombre'];
                $_SESSION['temas'] = $filas['n_temas'];
                $_SESSION['post'] = $filas['n_post'];
                echo "<script>window.location='inicio.php';</script>";
            }
        }
    } else {
        echo '<script language="javascript">alert("no existe");</script>';
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.1.3/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <title>Document</title>
</head>

<body>

    <div class="wrapper">
        <div class="logo">
            <img src="https://cdn-icons-png.flaticon.com/512/2412/2412855.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            Foro
        </div>
        <form class="p-3 mt-3" action="" method="post">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="email" name="email" id="userName" placeholder="Email" required>
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="pass" id="pwd" placeholder="Password" required>
            </div>
            <button type="submit" class="btn mt-3" name="enviar" value="enviar">Login</button>
        </form>
        <div class="text-center fs-6">
            <a href="#">Forget password?</a> or <a href="registro.php">Sign up</a>
        </div>
    </div>
</body>

</html>