<?php

// require_once('conecta_bd.php');

class usuarios
{
    public $nombre;
    public $email;
    public $pass;
    public $tipo;
    public $avatar;
    public $temas = 0;
    public $post = 0;


    public function __construct($nom, $em, $pas, $tip, $avat)
    {
        $this->nombre = $nom;
        $this->email = $em;
        $this->pass = $pas;
        $this->tipo = $tip;
        $this->avatar = $avat;
    }


    public static function crear($usario)
    {
        $host = "localhost";
        $usuario = "root";
        $password = "";
        $db = "foro";
        $conexion = new mysqli($host, $usuario, $password, $db);

        $alta = "INSERT INTO usuarios (nombre,email,pass,tipo_user,avatar,n_temas,n_post) values ('$usario->nombre','$usario->email','$usario->pass','$usario->tipo', '$usario->avatar','$usario->temas','$usario->post')";
        $conexion->query($alta);
        $mensaje = "

El usuario " . $usario->nombre . " ha sido dado de Alta
";
        $conexion->close();
        echo $mensaje;
    }













    // public static function comprobar($usario)
    // {
    //     $host = "localhost";
    //     $usuario = "root";
    //     $password = "";
    //     $db = "foro";
    //     $conexion = new mysqli($host, $usuario, $password, $db);

    //     $query = "SELECT * FROM `usuarios` WHERE email = '$usario->email' AND pass= '$usario->pass'";
    //     $result =  $conexion->query($query);
    //     $rows = mysqli_num_rows($result);
    //     if ($rows == 1) {
    //         $_SESSION['tipo'] = $usario->tipo;
    //         $_SESSION['nombre'] = $usario->nombre;
    //         echo "<script>window.location='inicio.php';</script>";
    //     } else {

    //         echo '<script language="javascript">alert("no existe");</script>';
    //     }
    // }

}
