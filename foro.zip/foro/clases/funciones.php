<?php
function categorias()
{
    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "foro";
    $conexion = new mysqli($host, $usuario, $password, $db);

    $sql = "SELECT * FROM categorias";
    $result = $conexion->query($sql);



    if ($result->num_rows > 0) {
        while ($filas = $result->fetch_array()) {
            echo "<option value = " . $filas['cod'] . ">" . $filas['categoria'] . "</option>";
        }
    } else {
        echo 'no hay resultados';
    }
}


function actualizartemas($temas, $nombre)
{

    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "foro";
    $conexion = new mysqli($host, $usuario, $password, $db);

    $sql = "UPDATE usuarios SET n_temas = $temas WHERE  nombre = '$nombre'";

    $conexion->query($sql);
}



function gettemas($cod)
{
    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "foro";
    $conexion = new mysqli($host, $usuario, $password, $db);

    $sql = "SELECT * FROM temas WHERE cod = '$cod'";
    $result = $conexion->query($sql);



    if ($result->num_rows > 0) {
        while ($filas = $result->fetch_array()) {
            echo $filas['nombre'];
        }
    } else {
        echo 'no hay resultados';
    }
}


function actualizarpost($post, $nombre)
{

    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "foro";
    $conexion = new mysqli($host, $usuario, $password, $db);

    $sql = "UPDATE usuarios SET n_post = $post WHERE  nombre = '$nombre'";

    $conexion->query($sql);
}
