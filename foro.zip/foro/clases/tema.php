<?php




class temas {


public $nombre;
public $descripcion;
public $data_creacion;
public $categoria;
public $usuario;
public $tipo;

public function __construct($nom,$descripcion,$data,$categoria,$usuario,$tipo)
{
    $this->nombre = $nom;
    $this->descripcion = $descripcion;
    $this->data_creacion = $data;
    $this->categoria = $categoria;
    $this->usuario = $usuario;
    $this->tipo = $tipo;
}



public static function crear($usario)
{
    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "foro";
    $conexion = new mysqli($host, $usuario, $password, $db);

    $alta = "INSERT INTO temas (nombre,descripcion,data_creacion,categoria,usuario,tipo_user) values ('$usario->nombre','$usario->descripcion','$usario->data_creacion','$usario->categoria','$usario->usuario','$usario->tipo')";
    $conexion->query($alta);
    $mensaje = "

El usuario " . $usario->nombre . " ha sido dado de Alta
";
    $conexion->close();
    // echo $mensaje;
}

    
}
