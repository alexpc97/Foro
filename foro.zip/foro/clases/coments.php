<?php



class comentarios {

    public $titulo;
    public $comentario;
    public $data_creacion;
    public $usuario;


public function __construct($titulo,$comentario,$usuario)
{
    $this->titulo = $titulo;
    $this->comentario = $comentario;
    $this->data_creacion = date('Y-m-d');
    $this->usuario = $usuario;
}

public static function crear($usario)
{
    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "foro";
    $conexion = new mysqli($host, $usuario, $password, $db);

    $alta = "INSERT INTO comentarios (titulo,comentario,data_creacion,usuario) values ('$usario->titulo','$usario->comentario','$usario->data_creacion','$usario->usuario')";
    $conexion->query($alta);
    $mensaje = "

El usuario " . $usario->comentario . " ha sido dado de Alta
";
    $conexion->close();
    // echo $mensaje;
}
    
}