<?php



$host="localhost";
$usuario="root";
$password="";
$db="foro";
$con = mysqli_connect($host,$usuario,$password,$db);

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
//VERSION CON OBXETOS
$conexion = new mysqli($host,$usuario,$password,$db);




$sql = "create table if not exists usuarios(
  email varchar(50)  not null ,
  pass varchar(50),
  nombre varchar(50) not null,
  n_temas int,
  n_post int,
  avatar varchar(50),
  tipo_user varchar(50),
   PRIMARY KEY (nombre)
)";
$conexion->query($sql);

$categoria = "create table if not exists categorias(
  cod int auto_increment  not null,
  categoria varchar(50) not null,
  descripcion varchar(500),
  data_creacion date,
   PRIMARY KEY (cod)
)";
$conexion->query($categoria);

$temas = "create table if not exists temas(
  cod int auto_increment  not null,
  nombre varchar(50),
  descripcion varchar(500),
  data_creacion date,
  categoria int,
  usuario varchar(50),
  tipo_user varchar(50),
   PRIMARY KEY (cod),
   CONSTRAINT FOREIGN KEY(categoria) REFERENCES categorias(cod) ON DELETE CASCADE,
   CONSTRAINT FOREIGN KEY(usuario) REFERENCES usuarios(nombre) ON DELETE CASCADE
   
)";

$conexion->query($temas);


$comentarios ="create table if not exists comentarios(
  cod int auto_increment not null,
  titulo int,
  comentario varchar(500),
  data_creacion date,
  usuario varchar(50),
  PRIMARY KEY (cod),
  CONSTRAINT FOREIGN KEY(usuario) REFERENCES usuarios(nombre) ON DELETE CASCADE,
  CONSTRAINT FOREIGN KEY(titulo) REFERENCES temas(cod) ON DELETE CASCADE
)";

$conexion->query($comentarios);

?>