<?php

session_start();

require_once('conecta_bd.php');
require_once('clases/usuarios.php');
require_once('clases/funciones.php');
require_once('clases/tema.php');
require_once('clases/coments.php');

$usuario = $_SESSION['nombre'];
$tipo = $_SESSION['tipo'];




switch ($_SESSION['tipo']) {
    case 'creador':
        require_once('menu/nav.html');
        break;
    case 'admin':
        require_once('menu/admin.html');
        break;
    case 'lector':
        require_once('menu/lector.html');
        break;
    case 'comentador':
        require_once('menu/lector.html');
        break;
    default:
        # code...
        break;
}
// echo  $_SESSION['nombre'] . ' : ' . $_SESSION['tipo'] . ' : ' . $_SESSION['temas'];

// if (isset($_POST['comentar'])) {
//     $_SESSION['codtitulo'] = $_POST['categoria'];

//     header("Location: comentarios.php");
//     exit();
// }

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/comentsprev.css">
    <link rel="stylesheet" href="css/cards.css">
    <title>Document</title>
</head>

<body>

    <section class="wrappers">
        <div class="container">
            <div class="row">
                <div class="col text-center mb-5">
                    <h1 class="display-4">Temas </h1>
                    <p class="lead">Aquí podras ver los mejores temas a comentar </p>
                </div>
            </div>
            <div class="row">
                <?php
                if ($tipo == "creador") {
                    $sql = "SELECT * FROM temas WHERE usuario = '$usuario'";
                } else {
                    $sql = "SELECT * FROM temas";
                }
                // $sql = "SELECT * FROM temas WHERE usuario = '$usuario' ";
                $result = $conexion->query($sql);
                if ($result->num_rows > 0) {
                    while ($filas = $result->fetch_array()) {


                ?>

                        <div class="col-sm-12 col-md-6 col-lg-4 mb-4">
                            <div class="card text-white card-has-bg click-col" style="background-image:url('https://source.unsplash.com/600x900/?tech,street');">
                                <img class="card-img d-none" src="https://source.unsplash.com/600x900/?tech,street" alt="Goverment Lorem Ipsum Sit Amet Consectetur dipisi?">
                                <div class="card-img-overlay d-flex flex-column">
                                    <div class="card-body">

                                        <h4 class="card-title mt-0 "><a class="text-white" herf="#"><?php echo $filas['nombre']; ?></a></h4>
                                        <p class="card-text"> <?php echo $filas['descripcion'] ?></p>
                                        <small><i class="far fa-clock"></i> <?php echo $filas['data_creacion']; ?></small>
                                    </div>
                                    <div class="card-footer">

                                        <div class="media">
                                            <img class="mr-3 rounded-circle" src="https://assets.codepen.io/460692/internal/avatars/users/default.png" alt="Generic placeholder image" style="max-width:50px; ">
                                            <div class="media-body">
                                                <h6 class="my-0 text-white d-block"><?php echo $filas['usuario'] ?></h6>
                                                <small><i class="far fa-clock"></i> <?php echo $filas['tipo_user']; ?></small>
                                                <!-- <a href="comentarios.php?codtitulo=<?php echo $filas['titulo']; ?>&usuario=<?php echo $filas['usuario']; ?>" class="btn btn-primary borrar">Borrar</a> -->
                                                <a href="comentarios.php?codtitulo=<?php echo $filas['cod']; ?>"  class="btn btn-primary borrar">Comentar</a>

                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                <?php
                    }
                }
                ?>


            </div>

        </div>
    </section>

</body>

</html>