<?php

session_start();

require_once('conecta_bd.php');
require_once('clases/usuarios.php');
require_once('clases/funciones.php');
require_once('clases/tema.php');
require_once('clases/coments.php');

$usuario = $_SESSION['nombre'];
$tipo = $_SESSION['tipo'];


switch ($_SESSION['tipo']) {
    case 'creador':
        require_once('menu/nav.html');
        break;
    case 'admin':
        require_once('menu/admin.html');
        break;
    case 'lector':
        require_once('menu/lector.html');
        break;
    case 'comentador':
        require_once('menu/lector.html');
        break;
    default:
        # code...
        break;
}
// echo  $_SESSION['nombre'] . ' : ' . $_SESSION['tipo'] . ' : ' . $_SESSION['temas'];


// if (isset($_SESSION['codtitulo'])) {
//     $codtitulo = $_SESSION['codtitulo'];
//     // echo $codtitulo;
// } else {
//     echo "no llega";
// }
if (isset($_GET['codtitulo'])) {
    $_SESSION['codtitulo'] = $_GET['codtitulo'];
    $codtitulo = $_SESSION['codtitulo'];
    // echo $codtitulo;
} else {
    echo "no llega";
}



if (isset($_POST['btncoment'])) {
    $coment = $_POST['msg'];
    $new_coment = new comentarios($codtitulo, $coment, $usuario);
    comentarios::crear($new_coment);

    $_SESSION['post']+=1;
    actualizarpost($_SESSION['post'],$usuario);
}




?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/coments.css">
    <title>Document</title>
</head>

<body>

    <!-- Main Body -->

    <div class="container">
        <div class="row">
            <div class="col-sm-5 col-md-6 col-12 pb-4">
                <h1> Coments to <?php gettemas($codtitulo) ?></h1>


                <?php
                if ($_SESSION['tipo'] == "admin" || $_SESSION['tipo'] == "comentador" || $_SESSION['tipo'] == "lector") {
                    $sql = "SELECT * FROM comentarios WHERE titulo = '$codtitulo' ";
                } else {
                    $sql = "SELECT * FROM comentarios WHERE usuario = '$usuario' AND titulo = '$codtitulo' ";
                }

                $result = $conexion->query($sql);
                if ($result->num_rows > 0) {
                    while ($filas = $result->fetch_array()) {

                ?>

                        <div class="comment mt-4 text-justify float-left">
                            <img src="https://i.imgur.com/yTFUilP.jpg" alt="" class="rounded-circle" width="40" height="40">
                            <h4><?php echo $filas['usuario']; ?></h4>
                            <span><?php echo $filas['data_creacion']; ?></span>
                            <br>
                            <p><?php echo $filas['comentario']; ?></p>
                        </div>

                <?php
                    }
                }
                ?>

            </div>

            <?php

            if ($_SESSION['tipo'] == "lector") {
            } else {



            ?>

                <div class="col-lg-4 col-md-5 col-sm-4 offset-md-1 offset-sm-1 col-12 mt-4">
                    <form id="algin-form" action="" method="post">
                        <div class="form-group">
                            <h4>Leave a comment</h4>
                            <label for="message" id="mensaj">Message</label>
                            <textarea name="msg" id="" msg cols="30" rows="5" class="form-control"required></textarea>
                        </div>
                        <!-- <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="fullname" class="form-control">
                    </div>
                    <div class="form-group ">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="email" class="form-control">
                    </div> -->

                        <div class="form-group">
                            <button type="submit" name="btncoment" value="btncoment" class="btn">Post Comment</button>
                        </div>
                    </form>
                </div>
            <?php
            }
            ?>
        </div>
    </div>

</body>

</html>