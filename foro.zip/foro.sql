-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-05-2024 a las 17:00:28
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `foro`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `cod` int(11) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `data_creacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`cod`, `categoria`, `descripcion`, `data_creacion`) VALUES
(2, 'fantasia', 'aaaaaaaaaaaaaaaaaaaaaah', '2023-04-05'),
(3, 'terror', 'muero', '2023-04-05'),
(4, 'animacion', 'chuliiiiii', '2023-04-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `cod` int(11) NOT NULL,
  `titulo` int(11) DEFAULT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `data_creacion` date DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`cod`, `titulo`, `comentario`, `data_creacion`, `usuario`) VALUES
(61, 21, 'me molo bastante ha sido una experiencia increible', '2023-04-08', 'spiderman'),
(62, 21, 'en una palabra : fantastico', '2023-04-08', 'spiderman'),
(63, 28, 'buenisimo', '2023-04-08', 'spiderman'),
(64, 22, 'ola', '2023-04-08', 'spiderman'),
(65, 22, 'buah lo mejor de mi vda', '2023-04-08', 'spiderman'),
(66, 22, 'plplpl', '2023-11-18', 'spiderman'),
(67, 22, 'me ha encantado', '2023-11-18', 'spiderman'),
(68, 21, 'hey que tal \r\n', '2024-02-13', 'bachata'),
(69, 21, 'hey que tal \r\n', '2024-02-13', 'bachata'),
(70, 21, 'what', '2024-02-13', 'bachata'),
(71, 22, 'prefecrt', '2024-02-13', 'bachata'),
(72, 22, 'sss\r\njkkll', '2024-02-13', 'bachata'),
(73, 22, 'prefecrt', '2024-02-13', 'bachata'),
(74, 22, 'ddd', '2024-02-13', 'bachata'),
(75, 21, 'what', '2024-02-13', 'bachata'),
(76, 26, 'cccccccccc', '2024-02-13', 'bachata'),
(77, 22, 'jfijlkijhflkjhlkfj', '2024-02-16', 'bachata'),
(78, 22, 'gg', '2024-02-16', 'bachata'),
(79, 22, 'kghkfhkjhlkjgf\r\n', '2024-02-16', 'bachata'),
(80, 21, 'ha sido muy buena me a encantado de principio a fin ', '2024-05-21', 'bachata'),
(81, 21, 'cool', '2024-05-21', 'bachata'),
(82, 26, 'lo mejor que he visto en mi vida ', '2024-05-21', 'bachata'),
(83, 26, 'pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp', '2024-05-21', 'bachata'),
(84, 26, 'ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooopopoppoo', '2024-05-21', 'bachata');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temas`
--

CREATE TABLE `temas` (
  `cod` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `data_creacion` date DEFAULT NULL,
  `categoria` int(11) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `tipo_user` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `temas`
--

INSERT INTO `temas` (`cod`, `nombre`, `descripcion`, `data_creacion`, `categoria`, `usuario`, `tipo_user`) VALUES
(21, 'scream', 'zzzzzzzzz', '2023-04-06', 2, 'nitendo', 'admin'),
(22, 'sssss', 'xxxxx', '2023-04-07', 2, 'spiderman', 'creador'),
(26, 'spiderman2', 'xxxxxxxx', '2023-04-08', 2, 'nitendo', 'admin'),
(28, 'horizon', 'xxxxx', '2023-04-08', 2, 'spiderman', 'creador'),
(30, 'vwngados', 'xxxxx', '2023-04-08', 2, 'luis ', 'creador'),
(31, 'exor', 'jhgkdhjgkjhgkdjhgfj', '2023-04-08', 3, 'luis ', 'creador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `n_temas` int(11) DEFAULT NULL,
  `n_post` int(11) DEFAULT NULL,
  `avatar` varchar(50) DEFAULT NULL,
  `tipo_user` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`email`, `pass`, `nombre`, `n_temas`, `n_post`, `avatar`, `tipo_user`) VALUES
('a@io.com', 'c', 'bachata', 1, 17, '#000000', 'admin'),
('cloud@io.com', '7', 'cloud', 0, 0, '#146276', 'lector'),
('luis@u.com', 'l', 'luis ', 3, 0, '#000000', 'creador'),
('se@io.com', 'a', 'nitendo', 2, 0, '#000000', 'admin'),
('saphira@io.com', 's', 'saphira', 0, 0, '#000000', 'comentador'),
('peterq@io.com', 'z', 'spiderman', 2, 7, '#f50a0a', 'creador'),
('uuuuuuu@io.com', '1', 'uuuuuuu', 0, 0, '#000000', 'admin'),
('yo@io.com', 'u', 'yo', 0, 0, '#000000', 'admin');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`cod`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `usuario` (`usuario`),
  ADD KEY `titulo` (`titulo`);

--
-- Indices de la tabla `temas`
--
ALTER TABLE `temas`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `categoria` (`categoria`),
  ADD KEY `usuario` (`usuario`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`nombre`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT de la tabla `temas`
--
ALTER TABLE `temas`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`nombre`) ON DELETE CASCADE,
  ADD CONSTRAINT `comentarios_ibfk_2` FOREIGN KEY (`titulo`) REFERENCES `temas` (`cod`) ON DELETE CASCADE;

--
-- Filtros para la tabla `temas`
--
ALTER TABLE `temas`
  ADD CONSTRAINT `temas_ibfk_1` FOREIGN KEY (`categoria`) REFERENCES `categorias` (`cod`) ON DELETE CASCADE,
  ADD CONSTRAINT `temas_ibfk_2` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`nombre`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
